#!/bin/bash
set -e

SUDO=""
if [ "$(id -u)" -ne 0 ]; then
    SUDO="sudo"
fi

echo "Removendo VxVoice..."
${SUDO} pkill -9 -x VxVoice 2>/dev/null || true
${SUDO} rm -f /usr/bin/VxVoice
${SUDO} rm -rf /usr/lib/vxvoice
${SUDO} rm -f /usr/share/applications/vxvoice.desktop
${SUDO} rm -f /usr/share/pixmaps/vxvoice.png
for res in 16 24 32 48 64 128 256; do
    ${SUDO} rm -f "/usr/share/icons/hicolor/${res}x${res}/apps/vxvoice.png"
done
${SUDO} rm -rf /usr/share/vxvoice
${SUDO} ldconfig 2>/dev/null || true
${SUDO} update-desktop-database /usr/share/applications 2>/dev/null || true
echo "VxVoice removido."
