#!/bin/bash
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SUDO=""
if [ "$(id -u)" -ne 0 ]; then
    SUDO="sudo"
fi

echo "=========================================="
echo "  Instalador Universal VxVoice v3.0.4 (Linux)"
echo "=========================================="

echo "[1/5] Verificando dependências de runtime (Qt6 / ALSA)..."
if command -v apt-get >/dev/null 2>&1; then
    if ! dpkg -s libqt6widgets6 >/dev/null 2>&1 && ! dpkg -s libqt6widgets6t64 >/dev/null 2>&1; then
        ${SUDO} apt-get update -qq || true
        ${SUDO} apt-get install -y libqt6widgets6t64 libqt6network6t64 libqt6gui6t64 libqt6core6t64 libasound2t64 || \
        ${SUDO} apt-get install -y libqt6widgets6 libqt6network6 libqt6gui6 libqt6core6 libasound2 || true
    fi
elif command -v dnf >/dev/null 2>&1; then
    rpm -q qt6-qtbase-gui >/dev/null 2>&1 || ${SUDO} dnf install -y qt6-qtbase qt6-qtbase-gui alsa-lib || true
elif command -v pacman >/dev/null 2>&1; then
    pacman -Qi qt6-base >/dev/null 2>&1 || ${SUDO} pacman -Sy --noconfirm qt6-base alsa-lib || true
elif command -v zypper >/dev/null 2>&1; then
    rpm -q libQt6Widgets6 >/dev/null 2>&1 || ${SUDO} zypper --non-interactive install libQt6Widgets6 libQt6Network6 libQt6Gui6 libQt6Core6 libasound2 || true
fi

echo "[2/5] Instalando binário em /usr/bin/VxVoice e bibliotecas PJSIP em /usr/lib/vxvoice..."
${SUDO} install -Dm755 "${SCRIPT_DIR}/bin/VxVoice" /usr/bin/VxVoice
${SUDO} mkdir -p /usr/lib/vxvoice
if ls "${SCRIPT_DIR}/lib/vxvoice/"*.so* >/dev/null 2>&1; then
    ${SUDO} cp -a "${SCRIPT_DIR}/lib/vxvoice/"*.so* /usr/lib/vxvoice/
fi
${SUDO} ldconfig 2>/dev/null || true

echo "[3/5] Instalando ícones do sistema..."
if [ -f "${SCRIPT_DIR}/icons/app_icon.png" ]; then
    ${SUDO} install -Dm644 "${SCRIPT_DIR}/icons/app_icon.png" /usr/share/pixmaps/vxvoice.png
fi
for res in 16 24 32 48 64 128 256; do
    if [ -f "${SCRIPT_DIR}/icons/${res}x${res}/vxvoice.png" ]; then
        ${SUDO} install -Dm644 "${SCRIPT_DIR}/icons/${res}x${res}/vxvoice.png" "/usr/share/icons/hicolor/${res}x${res}/apps/vxvoice.png"
    fi
done

echo "[4/5] Instalando arquivos de áudio e atalho do menu..."
${SUDO} mkdir -p /usr/share/vxvoice/sounds
if ls "${SCRIPT_DIR}/sounds/"*.wav >/dev/null 2>&1; then
    ${SUDO} cp "${SCRIPT_DIR}/sounds/"*.wav /usr/share/vxvoice/sounds/
fi
if [ -f "${SCRIPT_DIR}/vxvoice.desktop" ]; then
    ${SUDO} install -Dm644 "${SCRIPT_DIR}/vxvoice.desktop" /usr/share/applications/vxvoice.desktop
fi

echo "[5/5] Atualizando cache de ícones e aplicativos..."
${SUDO} update-desktop-database /usr/share/applications 2>/dev/null || true
${SUDO} gtk-update-icon-cache -f -t /usr/share/icons/hicolor 2>/dev/null || true

echo ""
echo "VxVoice v3.0.4 instalado com sucesso!"
echo "Execute 'VxVoice' no terminal ou abra pelo menu de aplicativos."
